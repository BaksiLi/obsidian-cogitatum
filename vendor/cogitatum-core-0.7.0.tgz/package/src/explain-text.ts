import { formatDiagnostic, quote } from "./inspection-text.js";
import { FORMAT_VERSION } from "./types.js";
import type { ExplainEffect, ExplainEntry, ExplainedSource, ExplainReference, SourceSpan } from "./types.js";

export const EXPLAIN_TEXT_VERSION = "1";

/** A readable projection of the existing compiler evidence, including failed
 * decisions and all host units. It neither evaluates reasoning nor edits source.
 */
export function formatExplain(source: ExplainedSource): string {
  if (source.version !== FORMAT_VERSION) throw new Error(`Unsupported source format ${source.version}; expected ${FORMAT_VERSION}.`);
  if (source.units.length !== source.documents.length || source.units.length !== source.graphs.length || source.units.length !== source.explanations.length) throw new Error("Explain inspection requires source, AST, graph and trace from the same compilation.");
  const lines = [
    `cogitatum-explain-text ${EXPLAIN_TEXT_VERSION}`, `format: ${quote(source.version)}`, `input: ${source.mode}`,
    `status: ${source.diagnostics.some(d => d.severity === "error") ? "partial" : "no-errors"}`,
    "Generated keys and locations apply only to this compilation."
  ];
  source.units.forEach((unit, index) => {
    const graph = source.graphs[index];
    const points = new Map(graph.points.map(point => [point.key, point]));
    const bearings = new Map(graph.bearings.map(bearing => [bearing.key, bearing]));
    const entries = source.explanations[index].entries;
    const entriesByLine = new Map(entries.map(entry => [entry.sourceSpan.startLine, entry]));
    const reference = (ref: ExplainReference | undefined): string => {
      if (!ref) return "unavailable";
      if ("id" in ref) return "unresolved @" + ref.id;
      const entity = ref.kind === "point" ? points.get(ref.key) : bearings.get(ref.key);
      if (!entity) return `unavailable ${ref.kind} ${quote(ref.key)}`;
      const name = "declaration" in entity ? entity.id : entity.handle;
      return `${ref.kind} ${name ? "@" + name : quote(ref.key)}${entity.sourceSpan ? " at " + location(entity.sourceSpan) : ""}`;
    };
    const effectText = (effect: ExplainEffect, entry: ExplainEntry): string => {
      switch (effect.kind) {
        case "preserveBody": return "Preserve ordinary body; it introduces no semantic context.";
        case "preserveNote": return `Preserve a literal note subtree${effect.parentSpan ? " under " + location(effect.parentSpan) : ""}.`;
        case "attachNote": return `${effect.note.origin === "constructor-description" ? "Constructor description" : "Object note"} belongs to ${reference(effect.note.target)}.`;
        case "selectNoteTarget": return `Select ${effect.targetKind} note slot from ${effect.contextSpan ? location(effect.contextSpan) : "no local context"}: ${reference(effect.target)}${crossings(effect.crossedBodySpans)}.`;
        case "localBearingMember": {
          const membership = `In local Bearing at ${location(effect.localBearingSpan)}: ${effect.function}`;
          if (!effect.eligible) return membership + ", not a source.";
          const outcome = entriesByLine.get(effect.localBearingSpan.startLine)?.effects
            .find(e => e.kind === "emitBearing" || e.kind === "rejectBearing");
          if (outcome?.kind === "emitBearing") return membership + `, eligible; included in ${reference(outcome.ref)}.`;
          if (outcome?.kind === "rejectBearing") return membership + `, eligible; no Bearing was created by the rejected header (${outcome.reason}).`;
          return membership + ", eligible; no header outcome available.";
        }
        case "focusPoint": return `Reuse Point @${effect.operand.id}: ${reference(effect.ref)}; this occurrence does not copy its shared content.`;
        case "focusBearing": return `Reuse Bearing @${effect.operand.id}: ${reference(effect.ref)}; its endpoints remain fixed.`;
        case "rejectFocus": return `Reject reuse${effect.operand ? " @" + effect.operand.id : ""}: ${effect.reason}.`;
        case "selectAttachment": return `Select exposed attachment from ${effect.ownerSpan ? location(effect.ownerSpan) : "no local context"}: ${reference(effect.target)}.`;
        case "selectBearing": return `Select referenced Bearing from use at ${location(effect.contextSpan)}: ${reference(effect.target)}.`;
        case "emitPoint": return `Declare ${reference(effect.ref)} (${effect.reason}).`;
        case "rejectPoint": return `Reject Point${effect.id ? " @" + effect.id : ""}: ${effect.reason}.`;
        case "implicitAttachment": return `Local context ${location(effect.contextSpan)} selects ${reference(effect.target)}${crossings(effect.crossedBodySpans)}.`;
        case "emitBearing": return `Construct ${reference(effect.ref)}: ${effect.bearing.kind}${effect.bearing.profile ? " by " + effect.bearing.profile : ""}([${effect.bearing.sources.map(reference).join(", ")}], ${reference(effect.bearing.target)}); target by ${effect.bearing.targetBy}, ${effect.reason}${effect.entailedBy ? `; already entailed by ${effect.entailedBy.map(reference).join(", ")}` : ""}.`;
        case "rejectBearing": return `Reject Bearing: ${effect.reason}${effect.bearing ? `; candidate ${effect.bearing.kind}([${effect.bearing.sources.map(reference).join(", ")}], ${reference(effect.bearing.target)})` : ""}.`;
        case "skipBearing": return `No Bearing: ${effect.reason}.`;
        case "frameOccurrence": {
          const presented = "Presented as " + MARK_NAMES[("role" in entry.recognition && entry.recognition.role) || "."];
          const fit = effect.fit === "home" ? (effect.focus ? `: the default beneath a ${effect.focus === "question" ? "Question" : "Point"} focus` : effect.intention === "none" ? ": relevance, which the mark leaves unqualified" : ": the mark's own relation")
            : effect.fit === "opposed" ? "; the clause alone constructs the relation, which the mark opposes"
            : effect.fit === "compatible" ? (effect.focus ? "; placement records relevance only" : "; the clause states another relation, which the mark does not oppose")
            : "; no relation";
          const intention = effect.intention === "unbound" ? `; ${effect.awaits} target unstated`
            : effect.intention === "none" && !effect.fit ? " and no function awaiting one" : "";
          return presented + fit + intention + ".";
        }
      }
    };
    lines.push("", `unit ${index + 1}: ${unit.kind} at lines ${unit.startLine}-${unit.endLine} (independent namespace)`);
    for (const entry of entries) {
      const r = entry.recognition;
      const mark = r.kind === "bearing" ? (r.selector ? "/" : "") + (r.members ? " member sources" : " listed sources")
        : ("role" in r && r.role ? " " + r.role : "selector" in r && r.selector ? " ." : "") + ("selector" in r && r.selector ? "/" : "");
      lines.push(`  ${location(entry.sourceSpan)} ${r.kind}${mark}`);
      for (const effect of entry.effects) lines.push("    " + effectText(effect, entry));
      if (entry.diagnosticCodes.length) lines.push("    Diagnostics: " + entry.diagnosticCodes.join(", ") + ".");
    }
  });
  lines.push("", `diagnostics (${source.diagnostics.length}):`);
  for (const diagnostic of source.diagnostics) lines.push(...formatDiagnostic(diagnostic));
  return lines.join("\n") + "\n";
}

const MARK_NAMES = { Q: "Question", C: "Claim", G: "Ground", O: "Objection", R: "Response", D: "Distinction", ".": "neutral Point" } as const;

function location(span: SourceSpan): string {
  return `${span.startLine}:${span.startColumn}-${span.endLine}:${span.endColumn}`;
}
function crossings(spans: SourceSpan[]): string {
  return spans.length ? "; through ordinary body at " + spans.map(location).join(", ") : "; no ordinary body crossed";
}
