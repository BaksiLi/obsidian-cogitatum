import { FORMAT_VERSION } from "@cogitatum/core";
import type {
  AstBlock, Bearing, BearingKind, BearingRef, BearingTarget, Diagnostic, ExplainedSource, ExplainEffect,
  ExplainEntry, ExplainRecognition, GraphIR, LocalBearingChildFunction, ObjectNote, PointRef, SourceParseMode, SourceSpan
} from "@cogitatum/core";
import { referenceKey } from "./projection.js";

export type ReadingReference =
  | { kind: "declares"; ref: PointRef; name?: string }
  | { kind: "uses"; ref: BearingTarget; name: string }
  | { kind: "annotates"; ref: BearingTarget }
  | { kind: "constructs"; ref: BearingRef; name?: string };

export type ReadingOccurrence = {
  kind: "occurrence";
  /** Opaque address within this projection, never an identity across revisions. */
  id: string;
  unitIndex: number;
  line: number;
  depth: number;
  sourceSpan: SourceSpan;
  /** Original physical lines for this occurrence, joined with LF. */
  raw: string;
  text: string;
  recognition: ExplainRecognition | { kind: "literal" };
  references: ReadingReference[];
  diagnostics: Diagnostic[];
};

export type ReadingSourceLine = {
  kind: "source";
  line: number;
  raw: string;
  /** Absent for host prose and fences outside the selected source units. */
  unitIndex?: number;
  diagnostics: Diagnostic[];
};

export type ReadingEndpoint = {
  occurrenceId: string;
  ref: BearingTarget;
  /** Evidence for a display location; does not create another graph identity. */
  basis: "self" | "local-bearing-member" | "context" | "declaration";
};

export type ReadingBearing = {
  bearing: Bearing;
  occurrenceId: string;
  sources: ReadingEndpoint[];
  target: ReadingEndpoint;
};

/**
 * What one active occurrence commits to, from Core's Explain trace and matching AST syntax.
 * `indentation`: the nearest local context chose the target. `explicit`: a named target fixed it.
 * `member`: a source in a local Bearing header, adding no relation of its own.
 * `note`: a note annotating the object its context exposes.
 * `none`: no relation, such as a bare C or neutral Point. `failed`: no surviving Bearing.
 */
export type ReadingCommitment = {
  occurrenceId: string;
  basis: "indentation" | "explicit" | "member" | "note" | "none" | "failed";
  /** The row whose Point or exposed Bearing was selected, or a member's local Bearing header. */
  contextOccurrenceId?: string;
  /** A surviving graph entity only; a failed candidate has none. */
  target?: BearingTarget;
  kind?: BearingKind;
  /** How the emitted relation is stated, independently of how its target is selected. */
  relationBy?: "mark" | "clause" | "default";
  /** Ordinary body rows the selection passed through, outermost first. */
  crossedOccurrenceIds: string[];
  /** For a local Bearing header: its ordered source member rows. */
  memberOccurrenceIds: string[];
  memberFunction?: LocalBearingChildFunction;
  reason?: Extract<ExplainEffect, { kind: "rejectBearing" | "skipBearing" }>["reason"];
};

export type ReadingUnit = {
  graph: GraphIR;
  occurrences: ReadingOccurrence[];
  bearings: ReadingBearing[];
  notes: ReadingNote[];
  /** Relation and note decisions at active, non-body occurrences, in source order. */
  commitments: ReadingCommitment[];
};

export type ReadingNote = {
  record: ObjectNote;
  occurrenceId: string;
  /** Existing source occurrences, in source order; never relocated to a use. */
  content: ReadingOccurrence[];
};

export type ReadingProjection = {
  version: string;
  mode: SourceParseMode;
  source: string;
  rows: (ReadingOccurrence | ReadingSourceLine)[];
  units: ReadingUnit[];
  diagnostics: Diagnostic[];
};

const spanKey = (span: SourceSpan) =>
  `${span.startLine}:${span.startColumn}:${span.endLine}:${span.endColumn}`;
const sameRef = (a: BearingTarget, b: BearingTarget) => referenceKey(a) === referenceKey(b);
const mismatch = (detail: string): never => { throw new Error(`Reading requires matching source and compiler output: ${detail}.`); };

/**
 * Project one original input and its explainSource result, from the same revision.
 * Core owns selection and resolution. This function indexes its evidence for a reader;
 * it never reconstructs a target from indentation, nearby names or rejected summaries.
 */
export function projectReading(source: string, explained: ExplainedSource): ReadingProjection {
  if (explained.version !== FORMAT_VERSION) mismatch("unsupported format");
  const count = explained.units.length;
  if ([explained.documents, explained.graphs, explained.explanations].some(items => items.length !== count)) {
    mismatch("unaligned source units");
  }
  const lines = explained.mode === "host" ? source.split(/\r\n|\r|\n/) : source.replace(/\r\n/g, "\n").split("\n");
  const diagnosticsAt = new Map<number, Diagnostic[]>();
  for (const diagnostic of explained.diagnostics) {
    const line = diagnostic.sourceSpan?.startLine;
    if (line !== undefined) diagnosticsAt.set(line, [...diagnosticsAt.get(line) ?? [], diagnostic]);
  }
  const occurrencesByLine = new Map<number, ReadingOccurrence>();
  const continuationLines = new Set<number>();
  const unitByLine = new Map<number, number>();
  const units = explained.units.map((unit, unitIndex): ReadingUnit => {
    const document = explained.documents[unitIndex], graph = explained.graphs[unitIndex];
    const explanation = explained.explanations[unitIndex];
    if ([document, graph, explanation].some(value => value.version !== explained.version)) mismatch("mixed format versions");
    if (unit.kind === "document" && unit.source !== source) mismatch("document source changed");
    if (unit.kind === "fence") {
      // Core strips at most the opening fence's three-space indentation. Checking
      // the selected text catches stale units without selecting Markdown again.
      const original = lines.slice(unit.startLine - 1, unit.endLine);
      const selected = unit.endLine < unit.startLine ? [] : unit.source.split("\n");
      if (original.length !== selected.length || selected.some((text, i) => {
        const removed = original[i].length - text.length;
        return removed < 0 || removed > 3 || original[i] !== " ".repeat(removed) + text;
      })) mismatch("selected source changed");
    }
    for (let line = unit.startLine; line <= unit.endLine; line++) {
      if (unitByLine.has(line)) mismatch("overlapping source units");
      unitByLine.set(line, unitIndex);
    }
    const entries = new Map(explanation.entries.map(entry => [spanKey(entry.sourceSpan), entry]));
    if (entries.size !== explanation.entries.length) mismatch("duplicate Explain locations");
    const evidenceByOccurrence = new Map<string, { entry: ExplainEntry; block: AstBlock }>();
    const occurrences: ReadingOccurrence[] = [];
    const graphRefs = new Set([
      ...graph.points.map(point => referenceKey({ kind: "point", key: point.key })),
      ...graph.bearings.map(bearing => referenceKey({ kind: "bearing", key: bearing.key }))
    ]);
    if (graphRefs.size !== graph.points.length + graph.bearings.length) mismatch("duplicate graph identities");
    const origins = new Map<string, ReadingOccurrence>();
    const bySpan = new Map<string, ReadingOccurrence>();
    const unitLines = unit.source.replace(/\r\n/g, "\n").split("\n");
    function visit(block: AstBlock, depth: number, literal: boolean): void {
      const span = block.sourceSpan, key = spanKey(span);
      const entry = entries.get(key);
      if (literal ? !!entry : !entry) mismatch("AST / Explain occurrence correspondence");
      const original = lines.slice(span.startLine - 1, span.endLine);
      const rawLines = block.raw.split("\n");
      const content = /^[ \t]*-\s+(.*)$/s.exec(rawLines[0])?.[1];
      if (span.startLine < unit.startLine || span.endLine > unit.endLine || span.endLine < span.startLine ||
        rawLines.length !== original.length || content === undefined ||
        original[0]?.slice(span.startColumn - 1) !== content ||
        span.endColumn !== original.at(-1)!.length + 1 ||
        unitLines.slice(span.startLine - unit.startLine, span.endLine - unit.startLine + 1).join("\n") !== block.raw) {
        mismatch("occurrence span or source changed");
      }
      for (let line = span.startLine; line <= span.endLine; line++) {
        if (occurrencesByLine.has(line) || continuationLines.has(line)) mismatch("overlapping occurrence lines");
        if (line !== span.startLine) continuationLines.add(line);
      }
      const occurrence: ReadingOccurrence = {
        kind: "occurrence", id: `u${unitIndex}:${key}`, unitIndex, line: span.startLine,
        depth, sourceSpan: span, raw: original.join("\n"), text: block.text,
        recognition: literal ? { kind: "literal" } : entry!.recognition,
        references: [], diagnostics: original.flatMap((_line, i) => diagnosticsAt.get(span.startLine + i) ?? [])
      };
      for (const effect of entry?.effects ?? []) {
        let reference: ReadingReference | undefined;
        if (effect.kind === "emitPoint") reference = { kind: "declares", ref: effect.ref, name: effect.id };
        if (effect.kind === "focusPoint" || effect.kind === "focusBearing") {
          reference = { kind: "uses", ref: effect.ref, name: effect.operand.id };
        }
        if (effect.kind === "emitBearing") {
          if (graph.bearings[effect.ref.graphIndex]?.key !== effect.ref.key) mismatch("Bearing index");
          reference = { kind: "constructs", ref: { kind: "bearing", key: effect.ref.key }, name: effect.ref.handle };
        }
        if (effect.kind === "attachNote" && effect.note.origin === "note") {
          reference = { kind: "annotates", ref: effect.note.target };
        }
        if (reference) {
          const identity = referenceKey(reference.ref);
          if (!graphRefs.has(identity)) mismatch("emitted or focused entity missing from graph");
          occurrence.references.push(reference);
          if (reference.kind === "declares" || reference.kind === "constructs") {
            if (origins.has(identity)) mismatch("multiple entity origins");
            origins.set(identity, occurrence);
          }
        }
      }
      occurrences.push(occurrence);
      occurrencesByLine.set(occurrence.line, occurrence);
      bySpan.set(key, occurrence);
      if (entry) { evidenceByOccurrence.set(occurrence.id, { entry, block }); entries.delete(key); }
      for (const child of block.children) visit(child, depth + 1, literal || block.annotation?.kind === "note");
    }
    document.blocks.forEach(block => visit(block, 0, false));
    if (entries.size || origins.size !== graphRefs.size) mismatch("incomplete occurrence evidence");
    const refers = (occurrence: ReadingOccurrence, ref: BearingTarget) =>
      occurrence.references.some(reference => sameRef(reference.ref, ref));
    const origin = (ref: BearingTarget) => origins.get(referenceKey(ref)) ?? mismatch("missing entity origin");
    const endpoint = (occurrence: ReadingOccurrence, ref: BearingTarget, basis: ReadingEndpoint["basis"]): ReadingEndpoint => {
      if (!refers(occurrence, ref)) mismatch("endpoint occurrence refers to another entity");
      return { occurrenceId: occurrence.id, ref, basis };
    };
    const members = new Map<string, Map<string, ReadingOccurrence>>();
    for (const occurrence of occurrences) {
      const membership = evidenceByOccurrence.get(occurrence.id)?.entry.effects.find(effect => effect.kind === "localBearingMember");
      if (!membership?.eligible || membership.function !== "source") continue;
      const group = spanKey(membership.localBearingSpan);
      const points = members.get(group) ?? new Map<string, ReadingOccurrence>();
      for (const reference of occurrence.references) if (reference.ref.kind === "point") {
        // Duplicate sources invalidate the entire joint Bearing in Core.
        points.set(referenceKey(reference.ref), occurrence);
      }
      members.set(group, points);
    }
    const bearings = graph.bearings.map((bearing): ReadingBearing => {
      const occurrence = origin({ kind: "bearing", key: bearing.key });
      const entry = evidenceByOccurrence.get(occurrence.id)!.entry;
      const emitted = entry.effects.find(effect => effect.kind === "emitBearing")!;
      const sources = bearing.sources.map(ref => {
        if (refers(occurrence, ref)) return endpoint(occurrence, ref, "self");
        if (emitted.reason === "local-bearing-containment") {
          const member = members.get(spanKey(occurrence.sourceSpan))?.get(referenceKey(ref));
          if (!member) mismatch("missing Linked source occurrence");
          return endpoint(member!, ref, "local-bearing-member");
        }
        return endpoint(origin(ref), ref, "declaration");
      });
      const contexts = entry.effects.filter(effect => effect.kind === "implicitAttachment");
      if (contexts.length !== (bearing.derivedBy === "structural" ? 1 : 0)) mismatch("missing or unexpected attachment context");
      let target: ReadingEndpoint;
      if (contexts.length) {
        const context = contexts[0];
        const selected = bySpan.get(spanKey(context.contextSpan));
        if (!sameRef(context.target, bearing.target) || !selected) mismatch("invalid attachment context");
        target = endpoint(selected!, bearing.target, "context");
      } else target = endpoint(origin(bearing.target), bearing.target, "declaration");
      return { bearing, occurrenceId: occurrence.id, sources, target };
    });
    const noteOrigins = new Set(graph.notes.map(record => spanKey(record.sourceSpan)));
    const attachedNotes = [...evidenceByOccurrence.values()].flatMap(({ entry }) => entry.effects.filter(effect => effect.kind === "attachNote"));
    if (noteOrigins.size !== graph.notes.length || attachedNotes.length !== graph.notes.length) mismatch("incomplete or duplicate note evidence");
    const notes = graph.notes.map((record): ReadingNote => {
      const occurrence = bySpan.get(spanKey(record.sourceSpan));
      if (!occurrence || !graphRefs.has(referenceKey(record.target))) mismatch("note source or target missing");
      const effects = evidenceByOccurrence.get(occurrence!.id)?.entry.effects;
      if (!effects?.some(effect => effect.kind === "attachNote" &&
        effect.note.origin === record.origin && sameRef(effect.note.target, record.target) &&
        spanKey(effect.note.sourceSpan) === spanKey(record.sourceSpan))) mismatch("note / Explain disagreement");
      const content = [occurrence!];
      if (record.origin === "note") {
        const index = occurrences.indexOf(occurrence!);
        for (let i = index + 1; i < occurrences.length && occurrences[i].depth > occurrence!.depth; i++) {
          if (occurrences[i].recognition.kind !== "literal") mismatch("active note descendant");
          content.push(occurrences[i]);
        }
      }
      return { record, occurrenceId: occurrence!.id, content };
    });
    const occurrenceAt = (span?: SourceSpan) => span ? bySpan.get(spanKey(span))?.id : undefined;
    const commitments = occurrences.flatMap((occurrence): ReadingCommitment[] => {
      const evidence = evidenceByOccurrence.get(occurrence.id);
      const entry = evidence?.entry;
      if (!entry || entry.recognition.kind === "body") return [];
      const effects = entry.effects;
      const find = <K extends ExplainEffect["kind"]>(kind: K) =>
        effects.find((effect): effect is Extract<ExplainEffect, { kind: K }> => effect.kind === kind);
      const crossed = (spans: SourceSpan[]) => spans.map(span => occurrenceAt(span) ?? mismatch("crossed body occurrence"));
      const base = { occurrenceId: occurrence.id, crossedOccurrenceIds: [] as string[], memberOccurrenceIds: [] as string[] };
      const membership = find("localBearingMember");
      if (membership && membership.function === "source") {
        return [{ ...base, basis: "member", contextOccurrenceId: occurrenceAt(membership.localBearingSpan), memberFunction: membership.function }];
      }
      const note = find("selectNoteTarget");
      if (note) {
        return [{ ...base, basis: note.target ? "note" : "failed", contextOccurrenceId: occurrenceAt(note.contextSpan),
          ...(note.target ? { target: note.target } : {}), crossedOccurrenceIds: crossed(note.crossedBodySpans) }];
      }
      const emitted = find("emitBearing");
      if (emitted) {
        // The occurrence pass validated this index; projected Bearings retain graph order.
        const route = bearings[emitted.ref.graphIndex];
        const context = find("implicitAttachment");
        const annotation = evidence!.block.annotation;
        const written = annotation && "operatorClause" in annotation && annotation.operatorClause;
        return [{
          ...base, basis: context ? "indentation" : "explicit", target: route.bearing.target, kind: route.bearing.kind,
          relationBy: written ? "clause" : entry.recognition.kind === "bearing" ? "default" : "mark",
          ...(context ? { contextOccurrenceId: route.target.occurrenceId, crossedOccurrenceIds: crossed(context.crossedBodySpans) } : {}),
          memberOccurrenceIds: route.sources.filter(source => source.basis === "local-bearing-member").map(source => source.occurrenceId),
          ...(membership ? { memberFunction: membership.function } : {})
        }];
      }
      const rejected = find("rejectBearing"), skipped = find("skipBearing");
      const selection = find("selectAttachment"), use = find("selectBearing");
      const contextOccurrenceId = occurrenceAt(selection?.ownerSpan ?? use?.contextSpan);
      if (rejected) {
        return [{ ...base, basis: "failed", reason: rejected.reason, ...(rejected.bearing ? { kind: rejected.bearing.kind } : {}),
          ...(contextOccurrenceId ? { contextOccurrenceId } : {}), ...(membership ? { memberFunction: membership.function } : {}) }];
      }
      if (entry.recognition.kind === "note" || (entry.recognition.kind === "bearing" && !entry.recognition.members)) return [];
      return [{ ...base, basis: "none", ...(skipped ? { reason: skipped.reason } : {}), ...(membership ? { memberFunction: membership.function } : {}) }];
    });
    return { graph, occurrences, bearings, notes, commitments };
  });
  const rows = lines.flatMap((raw, index): (ReadingOccurrence | ReadingSourceLine)[] =>
    continuationLines.has(index + 1) ? [] : [occurrencesByLine.get(index + 1) ?? {
      kind: "source", line: index + 1, raw, unitIndex: unitByLine.get(index + 1), diagnostics: diagnosticsAt.get(index + 1) ?? []
    }]);
  return { version: explained.version, mode: explained.mode, source, rows, units, diagnostics: explained.diagnostics };
}

/** A declared Point nested without a relation at that occurrence: kept together in the drawing only. */
export type OutlineTie = { child: PointRef; parent: PointRef };

/**
 * Where the outline nests a declared Point under another and that occurrence itself states no relation,
 * as a Claim or a neutral Point beneath a Question does. A Map may keep them together with a faint tie.
 * The tie is the author's arrangement, never a Bearing or an inference about what the Point answers.
 * A use, a failed occurrence, and a member do not provide that evidence. If a Bearing already joins this Point
 * and its outline parent, that relation is the connection and no tie is added.
 * Keys belong to this unit: host units repeat anonymous keys, so ties are never gathered across them.
 */
/**
 * The occurrence an editor cursor on a one-based source line stands in.
 * An occurrence's span covers its own lines and children follow it in source order,
 * so the latest occurrence starting at or before the line is the innermost one containing it;
 * between blocks it is the nearest preceding occurrence.
 */
export function occurrenceAtLine(unit: ReadingUnit, line: number): ReadingOccurrence | undefined {
  let found: ReadingOccurrence | undefined;
  for (const occurrence of unit.occurrences) {
    if (occurrence.sourceSpan.startLine > line) break;
    found = occurrence;
  }
  return found;
}

export function outlineTies(unit: ReadingUnit): OutlineTie[] {
  const quiet = new Set(unit.commitments.filter(commitment =>
    commitment.basis === "none" && commitment.reason === "no-structural-rule").map(commitment => commitment.occurrenceId));
  const joined = new Set(unit.graph.bearings.flatMap(bearing =>
    bearing.target.kind === "point"
      ? bearing.sources.map(source => `${source.key}>${bearing.target.key}`)
      : []));
  const ties: OutlineTie[] = [], stack: { depth: number; point?: PointRef }[] = [];
  for (const occurrence of unit.occurrences) {
    while (stack.length && stack[stack.length - 1].depth >= occurrence.depth) stack.pop();
    const declared = occurrence.references.find(reference => reference.kind === "declares")?.ref;
    const parent = [...stack].reverse().find(entry => entry.point)?.point;
    if (declared && parent && declared.key !== parent.key && quiet.has(occurrence.id) &&
      !joined.has(`${declared.key}>${parent.key}`) && !joined.has(`${parent.key}>${declared.key}`)) {
      ties.push({ child: declared, parent });
    }
    const used = occurrence.references.find(reference => reference.kind === "uses")?.ref;
    stack.push({ depth: occurrence.depth, point: declared ?? (used?.kind === "point" ? used : undefined) });
  }
  return ties;
}
